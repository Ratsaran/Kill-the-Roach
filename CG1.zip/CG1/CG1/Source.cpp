#include <iostream>
#include <glut.h>
#include <GL.h>
void main(int argc, char** argv)
{
	int mode = GLUT_RGB | GLUT_SINGLE;
	glutInitDisplayMode(mode);
	glutInitWindowSize(500, 500);
	glutCreateWindow("Simple");
	glutMainLoop();
}
